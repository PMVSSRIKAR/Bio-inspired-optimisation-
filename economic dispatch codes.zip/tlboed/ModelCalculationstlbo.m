function out=ModelCalculationstlbo(P,model)

    alpha=model.Plants.alpha;
    beta=model.Plants.beta;
    gamma=model.Plants.gamma;
    e=model.Plants.e;
    f=model.Plants.f;
    C=alpha+beta.*P+gamma.*P.*P;
    C=C+abs(e.*sin(f.*(model.Plants.Pmin-P)));
    CTotal=sum(C);
    
    B=model.B;
    B0=model.B0;
    B00=model.B00;
    
    PL=P*B*P'+B0*P'+B00;
    
    PTotal=sum(P);
    
    PD=model.PD;
    
    PowerBalanceViolation=max(1-(PTotal-PL)/PD,0);
    
    q=100;
    z=CTotal*(1+q*PowerBalanceViolation);
    
    out.P=P;
    out.PTotal=PTotal;
    out.C=C;
    out.CTotoal=CTotal;
    out.PL=PL;
    out.PowerBalanceViolation=PowerBalanceViolation;
    out.z=z;

end