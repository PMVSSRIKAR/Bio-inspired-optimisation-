function [z, out]=MyCosttlbo(x,model)

    P=ParseSolutiontlbo(x,model);
    
    out=ModelCalculationstlbo(P,model);

    z=out.z;

end