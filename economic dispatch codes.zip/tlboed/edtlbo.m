tic
clc

model=CreateModeltlbo();
CostFunction=@(x) MyCosttlbo(x,model);
nplant=model.nPlant;
min_x1=0;
max_x1=1;
sum_x1=0;
    
        for i=1:1:(nplant*nplant)
    x1(1,i)=min_x1+(rand(1,1)*(max_x1-min_x1));
        end
    for j=1:1:(nplant)
    [fitness_val(j).Cost fitness_val(j).Out]=CostFunction(x1(1,((nplant*(j-1))+1):nplant*j));
    sum_x1=sum_x1+x1(1,i);
end
for d=1:1000
for i=1:1:nplant
    A2(1,i)=fitness_val(i).Cost;
end
k=min(A2);
for i=1:1:(nplant)
    if k==fitness_val(i).Cost
        p=i;
    end
end
mean_x1=sum_x1/(nplant*nplant);
%teacher phase
r1=rand(1,1);
difference_mean_x1=r1*(x1(1,p)-mean_x1);
for i=1:1:(nplant*nplant)
    ux1(1,i)=x1(1,i)+difference_mean_x1;
end
for i=1:1:(nplant)
     [ufitness_val(1,i).Cost ufitness_val(1,i).Out]=CostFunction(ux1(((nplant*(i-1))+1):nplant*i));
end
for i=1:1:(nplant)
    if ufitness_val(1,i).Cost<fitness_val(1,i).Cost
        x1_f(1,(nplant*(i-1))+1:nplant*i)=ux1(1,(nplant*(i-1))+1:nplant*i);
        fitness_val_f(1,i).Cost=ufitness_val(1,i).Cost;
    else
        x1_f(1,(nplant*(i-1))+1:nplant*i)=x1(1,(nplant*(i-1))+1:nplant*i);
        fitness_val_f(1,i).Cost=fitness_val(1,i).Cost;
    end
end
%learner phase
r3=rand(1,1);
for i=1:1:(nplant)-1
    if fitness_val_f(1,i).Cost>fitness_val_f(1,i+1).Cost
        uux1(1,(nplant*(i-1))+1:nplant*i)=x1_f(1,(nplant*(i-1))+1:nplant*i)+(r3*(x1_f(1,(nplant*(i))+1:nplant*(i+1))-x1_f(1,(nplant*(i-1))+1:nplant*i)));
        [uufitness_val(1,i).Cost uufitness_val(1,i).Out]=CostFunction(uux1(((nplant*(i-1))+1):nplant*i));
    else
         uux1(1,(nplant*(i-1))+1:nplant*i)=x1_f(1,(nplant*i)+1:nplant*(i+1))+(r3*(x1_f(1,(nplant*(i-1))+1:nplant*i))-x1_f(1,(nplant*i)+1:nplant*(i+1)));
        [uufitness_val(1,i).Cost uufitness_val(1,i).Out]=CostFunction(uux1(((nplant*(i-1))+1):nplant*i));
    end
end
if fitness_val_f((nplant)).Cost>fitness_val_f(1,1).Cost
        uux1(1,(nplant*nplant))=x1_f(1,(nplant*nplant))+(r3*(x1_f(1,1)-x1_f(1,(nplant*nplant))));
        [uufitness_val(1,nplant).Cost uufitness_val(1,nplant).Out]=CostFunction(uux1(((nplant*(nplant-1))+1):nplant*nplant));
    else
         uux1(1,(nplant*nplant))=x1_f(1,1)+(r3*(x1_f(1,(nplant*nplant))-x1_f(1,1)));
[uufitness_val(1,nplant).Cost uufitness_val(1,nplant).Out]=CostFunction(uux1(((nplant*(nplant-1))+1):nplant*nplant));
end
for i=1:1:(nplant)
    if uufitness_val(1,i).Cost<fitness_val_f(1,i).Cost
        x1_ff(1,nplant*(i-1)+1:nplant*i)=uux1(1,nplant*(i-1)+1:nplant*i);
        fitness_val_ff(1,i).Cost=uufitness_val(1,i).Cost;
    else
        x1_ff(1,nplant*(i-1)+1:nplant*i)=x1_f(1,nplant*(i-1)+1:nplant*i);
        fitness_val_ff(1,i).Cost=fitness_val_f(1,i).Cost;
    end
end;
for i=1:1:nplant
    B(1,i)=fitness_val_ff(i).Cost;
end
c_min5(d)=min(B);
    sum_x1=0;
for i=1:1:(nplant)
    x1(1,nplant*(i-1)+1:nplant*i)=x1_ff(1,nplant*(i-1)+1:nplant*i);
    fitness_val(1,i).Cost=fitness_val_ff(1,i).Cost;
end
 sum_x1=sum(x1(i));
end
figure;
plot(c_min5,'LineWidth',2);
xlabel('Iteration');
ylabel('Best Cost');
sum(c_min5)/1000 
toc