tic
clc
clear all
close all
model=CreateModelde();
CostFunction=@(x) MyCostde(x,model);
nplant=model.nPlant;
n=(nplant*nplant);
min_limit_x=0;
max_limit_x=1;
j=1;
for i=1:1:n
    V1(i,1)=min_limit_x+(rand(1,1)*(max_limit_x-min_limit_x));
    if V1(i,1)>0
        V1(i,1)=floor(V1(i,1));
    else
        V1(i,1)=ceil(V1(i,1));
    end
    for j=2:1:10
        V1(i,j)=floor(rand(1,1)*10);
    end
end

%D.E loop
for d=1:1:1000
    pc=0.2;
    for i=1:1:n
    %for V1 vectors
    bv=i;
    r1=i;
    r2=i;
    while bv==i
        bv=ceil(n*rand(1,1));
    end
     while r1==i||r1==bv
        r1=ceil(n*rand(1,1));
     end
      while r2==i||r2==bv||r2==r1
        r2=ceil(n*rand(1,1));
    end
    F=0.4;
    MV1(i,:)=V1(bv,:)+(F*(V1(r1,:)-V1(r2,:)));
    jrand=ceil(10*rand(1,1));
    for j=1:1:10
    if j==jrand||rand(1,1)<=pc
        trv1(i,j)=MV1(i,j);
    else
         trv1(i,j)=V1(i,j);
    end
    end
    end
    
for i=1:1:n
    y=[1;10^(-1);10^(-2);10^(-3);10^(-4);10^(-5);10^(-6);10^(-7);10^(-8);10^(-9)];
    val_tvr1(i,1)=trv1(i,:)*y;
    val_tar1(i,1)=V1(i,:)*y;
end
 concat1=[trv1;V1];
 val1=[val_tvr1;val_tar1];
 val=val1';
for j=1:1:(2*nplant)
    [fitness(j).Cost fitness(j).Out]=CostFunction(val(1,((nplant*(j-1))+1):nplant*j));
end
for i=1:1:2*nplant
    A(1,i)=fitness(i).Cost;
end
strongest(1,:)=sort(A(1,:),'ascend');
for i=1:1:nplant
    strongest_f(1,i)=strongest(1,i);
end
c_min1(d)=strongest_f(1,1);
for k=1:1:nplant
    for j=1:1:(2*nplant)
            if strongest_f(1,k)==fitness(j).Cost
                V1((nplant*(k-1))+1:nplant*k,:)=concat1((nplant*(j-1))+1:nplant*j,:);
            end
    end
end
end
figure;
plot(c_min1,'LineWidth',2);
xlabel('Iteration');
ylabel('Best Cost');
sum(c_min1)/1000
toc