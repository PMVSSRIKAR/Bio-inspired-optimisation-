function [z, out]=MyCostde(x,model)

    P=ParseSolutionde(x,model);
    
    out=ModelCalculationsde(P,model);

    z=out.z;

end