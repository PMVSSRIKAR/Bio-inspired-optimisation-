function P=ParseSolutionga(x,model)

     PminActual=model.Plants.PminActual;
    PmaxActual=model.Plants.PmaxActual;
    
    P=PminActual+(PmaxActual-PminActual).*x;
    
    PZ=model.Plants.PZ;
    nPlant=model.nPlant;
    for k=1:1:nPlant
    for i=1:nPlant
        for j=1:numel(PZ{i})
            if P(k)>PZ{i}{j}(1) && P(k)<PZ{i}{j}(2)
                % Correction
                if P(k)<(PZ{i}{j}(1)+PZ{i}{j}(2))/2
                    P(k)=PZ{i}{j}(1);
                else
                    P(k)=PZ{i}{j}(2);
                end
            end
        end
    end

end