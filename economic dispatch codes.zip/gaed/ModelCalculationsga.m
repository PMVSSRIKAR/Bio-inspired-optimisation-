function out=ModelCalculationsga(x,model)
P=x;
    alpha=model.Plants.alpha;
    beta=model.Plants.beta;
    gamma=model.Plants.gamma;
     e=model.Plants.e;
    f=model.Plants.f;
    nplant=model.nPlant;
     if numel(x)==nplant
       
         C=alpha+beta.*P+gamma.*P.*P;
        C= C+abs(e.*sin(f.*(model.Plants.Pmin-P)));
        
     end
     if numel(x)==5*nplant
        C=alpha+beta.*P+gamma.*P.*P;
        C= C+abs(e.*sin(f.*(model.Plants.Pmin-P)));
     end
    CTotal=sum(C);
    
    B=model.B;
    B0=model.B0;
    B00=model.B00;
     if numel(P)==nplant
        
        PL=P*B*P'+B0*P'+B00;
        
     end
      if numel(x)==5*nplant
       PL=P*B*P'+B0*P'+B00;
      end
    PTotal=sum(P);
    
    PD=model.PD;
    
    PowerBalanceViolation=max(1-(PTotal-PL)/PD,0);
    
    q=100;
    z=CTotal*(1+q*PowerBalanceViolation);
    
    out.P=P;
    out.PTotal=PTotal;
    out.C=C;
    out.CTotoal=CTotal;
    out.PL=PL;
    out.PowerBalanceViolation=PowerBalanceViolation;
    out.z=z;

end