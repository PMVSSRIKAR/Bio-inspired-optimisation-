tic
clc;

close all;
model=CreateModelga();
CostFunction=@(x) MyCostga(x,model);
nplant=model.nPlant;
x=rand(1,nplant*nplant*10)-0.5;
for k=1:(nplant*nplant*10)  
if x(k)<=0
    x_bin(k)=0;
else
    x_bin(k)=1;
end
end
for i=1:1:nplant*nplant
chr(i,:)=x_bin((10*(i-1)+1):(10*i)); 
end

 for d=1:1000
  
% dec1=bin2dec('chr1');
% dec2=bin2dec(chr2);
% dec3=bin2dec(chr3);
% dec4=bin2dec(chr4);
% dec5=bin2dec(chr5);
% dec6=bin2dec(chr6(1:10));
% dec7=bin2dec(chr7(1:10));
% dec8=bin2dec(chr8(1:10));
% dec9=bin2dec(chr9(1:10));
% dec10=bin2dec(chr10(1:10));
%specifieng particular range 
y=[512 256 128 64 32 16 8 4 2 1];
    for i=1:1:nplant*nplant
dec(i)=y*(chr(i,:))';
    end
min_r=0; 
max_r=1;
L=10;  
for i=1:1:nplant*nplant
act_val(i)=min_r+((max_r-min_r)*dec(i))/(2^L-1);
end
for j=1:1:nplant
[particle(j).Cost, particle(j).Out]=CostFunction(act_val(1,((nplant*(j-1))+1):nplant*j));
end
for i=1:1:nplant
x_f(i)=particle(i).Cost;
end
c_max=sort(x_f(1,:),'descend');
c_min=sort(x_f(1,:),'ascend');



for i=1:nplant
    for j=1:nplant
        if c_min(i)==x_f(j)
            ngchr(((nplant*(i-1))+1):nplant*i,:)=chr(((nplant*(j-1))+1:nplant*j),:);
        end
    end
end
%probability of cross over
pc=(0.1*nplant*nplant);
num_cross=pc*10;
k=1;
for i=1:num_cross
   
ran1=ceil(rand(1,1)*nplant*nplant); 
ran2=ceil(rand(1,1)*nplant*nplant);
ran_ngchr1=ngchr(ran1,:);
ran_ngchr2=ngchr(ran2,:);

ran3=ceil(rand(1,1)*10);
ran4=ran3+1; 
z(k,:)=[ran_ngchr1(1:ran3) ran_ngchr2(ran4:10)]; 
z(k+1,:)=[ran_ngchr2(1:ran3) ran_ngchr1(ran4:10)];
k=k+2;
end

k=1;

ran7=0.1*(2*nplant*nplant)*10;

for i=1:ran7
    ran5=ceil(rand(1,1)*10);
ran6=ceil(rand(1,1)*(2*nplant*nplant));
 ran_cross_child(i,:)=z(ran6,:);
    if ran_cross_child(i,ran5)==0
         ran_cross_child(i,ran5)=1;
    else 
        ran_cross_child(i,ran5)=0;
    end
  
end
  apend_mat=[chr;z;ran_cross_child];
 dec_apend_mat=y*(apend_mat)';
 min_r=0;
max_r=1;
L=10;
act_val_apend_mat=min_r+((max_r-min_r)*dec_apend_mat)/(2^L-1);
for j=1:1:5*nplant
[f_apend_mat(j).Cost, f_apend_mat(j).Out]=CostFunction(act_val_apend_mat(1,(nplant*(j-1)+1):nplant*(j)));
end
for j=1:1:5*nplant
A(1,j)=f_apend_mat(j).Cost;
end
c_min_apend_mat=sort(A(1,:),'ascend');
for i=1:5*nplant
    for j=1:(5*nplant)
        if c_min_apend_mat(i)==A(j)
            ngchr1((nplant*(i-1)+1):nplant*(i),:)=apend_mat((nplant*(j-1)+1):nplant*(j),:);
        end
    end
end
chr(1:(nplant*nplant),:)=ngchr1(1:(nplant*nplant),:);
c_min3(d)=c_min_apend_mat(1,1);
   end
 figure;
plot(c_min3,'LineWidth',2);
xlabel('Iteration');
ylabel('Best Cost');
 sum(c_min3)/1000 
%plot(c_max1)\
toc
    