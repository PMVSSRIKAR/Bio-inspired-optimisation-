function [z, out]=MyCostga(x,model)

    P=ParseSolutionga(x,model);
    
    out=ModelCalculationsga(P,model);

    z=out.z;

end