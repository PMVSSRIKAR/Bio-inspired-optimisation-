function [z, out]=MyCostpso(x,model)

    P=ParseSolutionpso(x,model);
    
    out=ModelCalculationspso(P,model);

    z=out.z;

end