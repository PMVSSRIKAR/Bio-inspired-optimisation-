tic
clc

model=CreateModeljaya();
CostFunction=@(x) MyCostjaya(x,model);
nplant=model.nPlant;
min_x1=0;
max_x1=1;
for i=1:1:(nplant*nplant)
    x1(1,i)=min_x1+(rand(1,1)*(max_x1-min_x1));
end
for i=1:1:nplant
     [fitness_val(i).Cost fitness_val(i).Out]=CostFunction(x1(1,(nplant*(i-1))+1:nplant*i));
end
for d=1:1000
    for i=1:1:nplant
    A1(i)=fitness_val(i).Cost;
    end
k1=min(A1);
k2=max(A1);
for i=1:1:nplant
    if k1==fitness_val(1,i).Cost
        p1=i;
    end
     if k2==fitness_val(1,i).Cost
        p2=i;
    end
end
r1=rand(1,1);
r2=rand(1,1);

for i=1:1:nplant*nplant
    ux1(1,i)=x1(1,i)+(r1*(x1(1,p1)-abs(x1(1,i))))-(r2*(x1(1,p2)-abs(x1(1,i))));
end
    for i=1:1:nplant
    [ufitness_val(i).Cost ufitness_val(i).Out]=CostFunction(ux1(1,((nplant*(i-1))+1):nplant*i));
end
for i=1:1:nplant
    if ufitness_val(1,i).Cost<fitness_val(1,i).Cost
        x1_f(1,(nplant*(i-1))+1:nplant*i)=ux1(1,(nplant*(i-1))+1:nplant*i);
        fitness_val_f(1,i).Cost=ufitness_val(1,i).Cost;
    else
        x1_f(1,(nplant*(i-1)+1):nplant*i)=x1(1,(nplant*(i-1))+1:nplant*i);
        fitness_val_f(1,i).Cost=fitness_val(1,i).Cost;
    end
end
for i=1:1:nplant
    B(1,i)=fitness_val_f(i).Cost;
end
c_min2(d)=min(B);
for i=1:1:nplant
    x1(1,(nplant*(i-1)+1):nplant*i)=x1_f(1,(nplant*(i-1))+1:nplant*i);
    fitness_val(1,i).Cost=fitness_val_f(1,i).Cost;
end
end
figure;
plot(c_min2,'LineWidth',2);
xlabel('Iteration');
ylabel('Best Cost');

sum(c_min2)/1000
toc