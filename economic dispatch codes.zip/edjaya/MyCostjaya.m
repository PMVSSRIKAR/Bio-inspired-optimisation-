function [z, out]=MyCostjaya(x,model)

    P=ParseSolutionjaya(x,model);
    
    out=ModelCalculationsjaya(P,model);

    z=out.z;

end